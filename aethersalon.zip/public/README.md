# Public Assets

Please add the following files to this directory:

1. **Aethersalon.png** - The main logo for the website
2. Any Victorian ornament images you want to use

These files will be served directly and can be accessed via `/filename.ext` in the application.
